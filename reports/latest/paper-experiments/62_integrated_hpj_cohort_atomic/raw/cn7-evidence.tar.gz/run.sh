#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-cohort-atomic-20260929
python3 scripts/integrated_hpj_cohort_atomic_study.py run --spec study-configs/integrated-hpj-cohort-atomic-development.json --output /home/wjxt/tokenfs-integrated-hpj-cohort-atomic-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-cohort-atomic-20260929 --freeze study-configs/integrated-hpj-cohort-atomic-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-cohort-atomic-evidence/development.exit
exit "$rc"
