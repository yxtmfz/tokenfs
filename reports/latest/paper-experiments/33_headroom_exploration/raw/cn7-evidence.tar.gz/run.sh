#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-headroom-exploration-20260929
python3 scripts/headroom_exploration_study.py run --spec study-configs/headroom-exploration-development.json --output /home/wjxt/tokenfs-headroom-exploration-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/headroom-exploration-20260929 --freeze study-configs/headroom-exploration-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-headroom-exploration-evidence/development.exit
exit "$rc"
