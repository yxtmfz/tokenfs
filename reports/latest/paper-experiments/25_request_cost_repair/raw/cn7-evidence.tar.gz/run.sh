#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-request-cost-20260928
python3 scripts/request_cost_study.py run --spec study-configs/request-cost-development.json --output /home/wjxt/tokenfs-request-cost-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/request-cost-20260928 --freeze study-configs/request-cost-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-request-cost-evidence/development.exit
exit "$rc"
