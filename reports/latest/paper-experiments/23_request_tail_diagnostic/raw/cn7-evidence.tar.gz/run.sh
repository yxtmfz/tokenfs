#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-tail-diagnostic-20260928
python3 scripts/tail_diagnostic_study.py run --spec study-configs/tail-diagnostic.json --output /home/wjxt/tokenfs-tail-diagnostic-evidence/diagnostic --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/tail-diagnostic-20260928 --freeze study-configs/tail-diagnostic-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-tail-diagnostic-evidence/diagnostic.exit
exit "$rc"
