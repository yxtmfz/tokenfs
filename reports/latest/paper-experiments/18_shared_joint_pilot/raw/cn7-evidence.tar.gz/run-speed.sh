#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-shared-joint-20260924
python3 scripts/shared_joint_pilot.py run --spec study-configs/shared-joint-pilot-development.json --output /home/wjxt/tokenfs-shared-joint-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/shared-joint-20260924 --freeze study-configs/shared-joint-pilot-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-shared-joint-evidence/speed.exit
exit "$rc"
