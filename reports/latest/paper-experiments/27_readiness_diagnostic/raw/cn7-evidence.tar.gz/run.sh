#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-readiness-diagnostic-20260928
python3 scripts/readiness_diagnostic_study.py run --spec study-configs/readiness-diagnostic.json --output /home/wjxt/tokenfs-readiness-diagnostic-evidence/diagnostic --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/readiness-diagnostic-20260928 --freeze study-configs/readiness-diagnostic-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-readiness-diagnostic-evidence/diagnostic.exit
exit "$rc"
