#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-contention-20260929
python3 scripts/integrated_hpj_contention_study.py run --spec study-configs/integrated-hpj-contention-development.json --output /home/wjxt/tokenfs-integrated-hpj-contention-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-contention-20260929 --freeze study-configs/integrated-hpj-contention-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-contention-evidence/development.exit
exit "$rc"
