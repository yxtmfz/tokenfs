#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-cohort-caller-freshness-20260930
python3 scripts/integrated_hpj_cohort_caller_freshness_study.py run --spec study-configs/integrated-hpj-cohort-caller-freshness-development.json --output /home/wjxt/tokenfs-integrated-hpj-cohort-caller-freshness-evidence/development --binary build-release/tokenfs --reference-binary /home/wjxt/projects/tokenfs-integrated-hpj-cohort-caller-lazy-20260930/build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-cohort-caller-freshness-20260930 --freeze study-configs/integrated-hpj-cohort-caller-freshness-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-cohort-caller-freshness-evidence/development.exit
exit "$rc"
