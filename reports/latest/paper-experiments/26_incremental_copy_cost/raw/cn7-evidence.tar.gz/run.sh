#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-incremental-cost-20260928
python3 scripts/incremental_cost_study.py run --spec study-configs/incremental-cost-development.json --output /home/wjxt/tokenfs-incremental-cost-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/incremental-cost-20260928 --freeze study-configs/incremental-cost-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-incremental-cost-evidence/development.exit
exit "$rc"
