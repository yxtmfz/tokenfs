#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-burst-reuse-20260925
for stage in correctness development; do
python3 scripts/burst_reuse_study.py run --spec study-configs/burst-reuse-$stage.json --output /home/wjxt/tokenfs-burst-reuse-evidence/$stage --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/burst-reuse-20260925 --freeze study-configs/burst-reuse-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-burst-reuse-evidence/$stage.exit
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
done
