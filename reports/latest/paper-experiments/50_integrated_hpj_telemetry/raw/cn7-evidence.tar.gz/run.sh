#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-telemetry-20260929
python3 scripts/integrated_hpj_telemetry_study.py run --spec study-configs/integrated-hpj-telemetry-development.json --output /home/wjxt/tokenfs-integrated-hpj-telemetry-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-telemetry-20260929 --freeze study-configs/integrated-hpj-telemetry-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-telemetry-evidence/development.exit
exit "$rc"
