#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-adaptive-control-20260928
for stage in correctness development; do
python3 scripts/adaptive_control_study.py run --spec study-configs/adaptive-control-$stage.json --output /home/wjxt/tokenfs-adaptive-control-evidence/$stage --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/adaptive-control-20260928 --freeze study-configs/adaptive-control-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-adaptive-control-evidence/$stage.exit
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
done
