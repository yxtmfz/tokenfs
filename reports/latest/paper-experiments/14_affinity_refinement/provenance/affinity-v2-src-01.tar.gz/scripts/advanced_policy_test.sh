#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mount_point="${TOKENFS_MOUNT:-/mnt/tokenfs}"
metadata_db="${TOKENFS_DB:-/var/lib/tokenfs/metadata/tokenfs.db}"
temp_config="$(mktemp /tmp/tokenfs-advanced.XXXXXX.yaml)"
qos_config="$(mktemp /tmp/tokenfs-qos.XXXXXX.yaml)"

cleanup() {
  "$project_root/scripts/stop_tokenfs.sh" "$mount_point" >/dev/null 2>&1 || true
  rm -f "$temp_config" "$qos_config"
}
trap cleanup EXIT

python3 - "$project_root/config/tokenfs.dev.yaml" "$temp_config" <<'PY'
import sys
from pathlib import Path

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
text = src.read_text(encoding="utf-8")
text = text.replace("local_quota_mib: 64", "local_quota_mib: 96", 1)
dst.write_text(text, encoding="utf-8")
PY

"$project_root/scripts/reset_dev_state.sh" "$mount_point" >/dev/null
cmake -S "$project_root" -B "$project_root/build" -G Ninja >/dev/null
cmake --build "$project_root/build" >/dev/null
"$project_root/scripts/start_tokenfs.sh" "$temp_config" "$mount_point" >/dev/null

echo "advanced: cost-driven eviction protects hot high-value files"
mkdir -p "$mount_point/gpu0/value"

python3 - "$mount_point/gpu0/value/hot.tokens" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"H" * 24 * 1024 * 1024)
PY

for _ in {1..6}; do
  cat "$mount_point/gpu0/value/hot.tokens" >/dev/null
done

python3 - "$mount_point/gpu0/value/cold.tokens" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"C" * 40 * 1024 * 1024)
PY

python3 - "$mount_point/gpu0/value/new.tokens" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"N" * 40 * 1024 * 1024)
PY

hot_tier="$(sqlite3 "$metadata_db" \
  "select tier from files where logical_path='/gpu0/value/hot.tokens';")"
if [[ "$hot_tier" != "local" ]]; then
  echo "expected hot high-value file to remain local"
  exit 1
fi

evict_count="$(sqlite3 "$metadata_db" \
  "select coalesce((select value from metrics where name='evict_count'),0);")"
if [[ "$evict_count" -lt 1 ]]; then
  echo "expected value-aware local eviction"
  exit 1
fi

echo "advanced: GPU affinity stats identify the dominant GPU"
cat "$mount_point/gpu0/value/hot.tokens" >/dev/null
cat "$mount_point/gpu0/value/hot.tokens" >/dev/null
for _ in {1..8}; do
  TOKENFS_GPU_ID=1 cat "$mount_point/gpu0/value/hot.tokens" >/dev/null
done
gpu0_reads="$(sqlite3 "$metadata_db" \
  "select coalesce((select read_count from gpu_access where logical_path='/gpu0/value/hot.tokens' and gpu_id=0),0);")"
if [[ "$gpu0_reads" -lt 2 ]]; then
  echo "expected gpu0 affinity reads to be recorded"
  exit 1
fi
gpu1_reads="$(sqlite3 "$metadata_db" \
  "select coalesce((select read_count from gpu_access where logical_path='/gpu0/value/hot.tokens' and gpu_id=1),0);")"
if [[ "$gpu1_reads" -lt 8 ]]; then
  echo "expected gpu1 cross-GPU affinity reads to be recorded"
  exit 1
fi
affinity_row="$(sqlite3 "$metadata_db" \
  "select dominant_gpu_id,dominant_gpu_read_share_x100,recent_dominant_gpu_id,recent_dominant_gpu_read_share_x100,recent_read_count,affinity_state,target_local_replica_count from files where logical_path='/gpu0/value/hot.tokens';")"
if [[ "$affinity_row" != "0|50|0|50|16|REMOTE_SHARED_HOT|2" ]]; then
  echo "expected hot file to be classified as recent shared hot after balanced GPU0/GPU1 reads"
  echo "actual: $affinity_row"
  exit 1
fi

echo "advanced: GPU affinity trend detects a shift to another GPU"
python3 - "$mount_point/gpu0/value/trend.tokens" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"T" * 1024 * 1024)
PY

for _ in {1..5}; do
  TOKENFS_GPU_ID=0 cat "$mount_point/gpu0/value/trend.tokens" >/dev/null
done
sqlite3 "$metadata_db" \
  "update gpu_access_events set access_at=access_at-400 where logical_path='/gpu0/value/trend.tokens' and gpu_id=0;"
for _ in {1..3}; do
  TOKENFS_GPU_ID=1 cat "$mount_point/gpu0/value/trend.tokens" >/dev/null
done
trend_row="$(sqlite3 "$metadata_db" \
  "select dominant_gpu_id,recent_dominant_gpu_id,recent_dominant_gpu_read_share_x100,recent_read_count,affinity_trend,affinity_state,target_local_replica_count from files where logical_path='/gpu0/value/trend.tokens';")"
if [[ "$trend_row" != "0|1|100|3|SHIFTING_TO_GPU1|AFFINITY_SHIFTING|1" ]]; then
  echo "expected affinity trend to shift from cumulative GPU0 to recent GPU1"
  echo "actual: $trend_row"
  exit 1
fi

echo "advanced: cross-GPU local replicas are created for shared hot remote data"
mkdir -p /var/lib/tokenfs/remote-sim/gpu0/xgpu
python3 - /var/lib/tokenfs/remote-sim/gpu0/xgpu/shared.tokens <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"X" * 1024 * 1024)
PY

for _ in {1..4}; do
  TOKENFS_GPU_ID=0 cat "$mount_point/gpu0/xgpu/shared.tokens" >/dev/null
done
for _ in {1..4}; do
  TOKENFS_GPU_ID=1 cat "$mount_point/gpu0/xgpu/shared.tokens" >/dev/null
done
TOKENFS_GPU_ID=1 cat "$mount_point/gpu0/xgpu/shared.tokens" >/dev/null

replica_row="$(sqlite3 "$metadata_db" \
  "select gpu_id,state,size_bytes from local_replicas where logical_path='/gpu0/xgpu/shared.tokens' and gpu_id=1;")"
if [[ "$replica_row" != "1|READY|1048576" ]]; then
  echo "expected a ready cross-GPU local replica on GPU1"
  echo "actual: $replica_row"
  exit 1
fi
if [[ ! -f /var/lib/tokenfs/local/gpu1/.tokenfs-replicas/gpu0/xgpu/shared.tokens ]]; then
  echo "expected physical cross-GPU replica file"
  exit 1
fi
replica_hits="$(sqlite3 "$metadata_db" \
  "select coalesce((select value from metrics where name='cross_gpu_local_replica_hit'),0);")"
if [[ "$replica_hits" -lt 1 ]]; then
  echo "expected cross_gpu_local_replica_hit"
  exit 1
fi

"$project_root/scripts/tokenfsctl.py" --config "$temp_config" metrics | grep -q "本地淘汰次数"
"$project_root/scripts/tokenfsctl.py" --config "$temp_config" metrics | grep -q "跨 GPU 本地副本创建"
"$project_root/scripts/tokenfsctl.py" --config "$temp_config" affinity | grep -q "REMOTE_SHARED_HOT"
"$project_root/scripts/tokenfsctl.py" --config "$temp_config" affinity | grep -q "AFFINITY_SHIFTING"
"$project_root/scripts/tokenfsctl.py" --config "$temp_config" replicas | grep -q "cross-gpu local replica"
"$project_root/scripts/tokenfsctl.py" --config "$temp_config" check
"$project_root/scripts/stop_tokenfs.sh" "$mount_point" >/dev/null

python3 - "$project_root/config/tokenfs.dev.yaml" "$qos_config" <<'PY'
import sys
from pathlib import Path

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
text = src.read_text(encoding="utf-8")
text = text.replace("qos_read_iops_per_gpu: 0", "qos_read_iops_per_gpu: 2")
text = text.replace("qos_background_mib_per_sec_per_gpu: 0", "qos_background_mib_per_sec_per_gpu: 1024")
text = text.replace("promote_on_read: false", "promote_on_read: true")
dst.write_text(text, encoding="utf-8")
PY

"$project_root/scripts/reset_dev_state.sh" "$mount_point" >/dev/null
"$project_root/scripts/start_tokenfs.sh" "$qos_config" "$mount_point" >/dev/null

echo "advanced: QoS engineering metrics record per-GPU delay"
mkdir -p "$mount_point/gpu0/qos"
printf "qos\n" >"$mount_point/gpu0/qos/tiny.tokens"
cat "$mount_point/gpu0/qos/tiny.tokens" >/dev/null
cat "$mount_point/gpu0/qos/tiny.tokens" >/dev/null
mkdir -p /var/lib/tokenfs/remote-sim/gpu0/qos
python3 - /var/lib/tokenfs/remote-sim/gpu0/qos/bg.tokens <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"B" * 1024 * 1024)
PY
cat "$mount_point/gpu0/qos/bg.tokens" >/dev/null
cat "$mount_point/gpu0/qos/bg.tokens" >/dev/null
qos_delay_ops="$(sqlite3 "$metadata_db" \
  "select coalesce((select value from metrics where name='qos_delay_ops'),0);")"
if [[ "$qos_delay_ops" -lt 1 ]]; then
  echo "expected qos_delay_ops"
  exit 1
fi
qos_background_ops="$(sqlite3 "$metadata_db" \
  "select coalesce((select value from metrics where name='qos_background_ops'),0);")"
if [[ "$qos_background_ops" -lt 1 ]]; then
  echo "expected qos_background_ops"
  exit 1
fi

"$project_root/scripts/tokenfsctl.py" --config "$qos_config" metrics | grep -q "QoS 延迟次数"
"$project_root/scripts/tokenfsctl.py" --config "$qos_config" metrics | grep -q "后台 QoS 操作"
"$project_root/scripts/tokenfsctl.py" --config "$qos_config" check

echo "TokenFS advanced policy test passed."
