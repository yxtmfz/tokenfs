#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-guarded-20260929
python3 scripts/integrated_hpj_guarded_study.py run --spec study-configs/integrated-hpj-guarded-development.json --output /home/wjxt/tokenfs-integrated-hpj-guarded-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-guarded-20260929 --freeze study-configs/integrated-hpj-guarded-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-guarded-evidence/development.exit
exit "$rc"
