#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-pathdiag-20260929
python3 scripts/integrated_hpj_pathdiag_study.py run --spec study-configs/integrated-hpj-pathdiag-development.json --output /home/wjxt/tokenfs-integrated-hpj-pathdiag-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-pathdiag-20260929 --freeze study-configs/integrated-hpj-pathdiag-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-pathdiag-evidence/development.exit
exit "$rc"
