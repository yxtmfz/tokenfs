#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-shared-pilot-20260924
python3 scripts/shared_cache_pilot.py run --spec study-configs/shared-cache-pilot-development.json --output /home/wjxt/tokenfs-shared-pilot-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/shared-pilot-20260924 --freeze study-configs/shared-cache-pilot-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-shared-pilot-evidence/speed.exit
exit "$rc"
