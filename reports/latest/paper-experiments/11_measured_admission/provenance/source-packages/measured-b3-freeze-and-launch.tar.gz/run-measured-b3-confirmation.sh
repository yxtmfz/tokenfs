set -eu
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-eval-20260919-b3
while ! test -f /home/wjxt/aura-kv-cn7/evidence/measured-b3-development-sequence.exit; do sleep 10; done
test "$(cat /home/wjxt/aura-kv-cn7/evidence/measured-b3-development-sequence.exit)" = 0
python3 scripts/measured_study.py audit --output /home/wjxt/aura-kv-cn7/evidence/measured-correctness-03
python3 scripts/measured_study.py audit --output /home/wjxt/aura-kv-cn7/evidence/measured-dev-06
python3 - <<'PY'
import hashlib,json,platform,shutil,sys,time
from pathlib import Path
sys.path.insert(0,'scripts')
from measured_study import application,digest,check_mount
freeze_path=Path('study-configs/measured-b3-freeze.json');freeze=json.loads(freeze_path.read_text())
for path,expected in freeze['hashes'].items():
 if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=expected:raise RuntimeError('changed frozen dependency: '+path)
windows={w['block']:w for w in freeze['public_windows']}
for name,record in freeze['specifications'].items():
 p=Path('study-configs',name+'.json')
 if hashlib.sha256(p.read_bytes()).hexdigest()!=record['sha256']:raise RuntimeError('changed specification: '+name)
 spec=json.loads(p.read_text())
 for b in spec['blocks']:
  if not b['scenario'].startswith('mooncake_'):continue
  w=windows[b['id']];source=Path('/home/wjxt/tokenfs-public-traces')/w['source']
  if hashlib.sha256(source.read_bytes()).hexdigest()!=w['source_sha256']:raise RuntimeError('changed public source')
  _,events,_=application(source,'confirmation',b['source_offset'],b['requests'],b['shard_mib'],b.get('paced',False))
  if digest(events)!=w['trace_sha256']:raise RuntimeError('changed public window: '+b['id'])
if shutil.disk_usage('/srv/tokenfs/remote-cn7').free<5*1024**3 or shutil.disk_usage('/home/wjxt/aura-kv-cn7/evidence').free<20*1024**3:raise RuntimeError('insufficient isolated test space')
context=dict(created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),host=platform.node(),kernel=platform.release(),python_version=platform.python_version(),freeze_sha256=hashlib.sha256(freeze_path.read_bytes()).hexdigest(),frozen_hashes=freeze['hashes'],**check_mount(Path('/srv/tokenfs/remote-cn7'),False))
Path('/home/wjxt/aura-kv-cn7/evidence/measured-b3-confirmation-execution-context.json').write_text(json.dumps(context,indent=2)+'\n')
print('B3_FROZEN_BINARY_SOURCE_SPEC_AND_PUBLIC_WINDOWS_VALIDATED',flush=True)
PY
for batch in measured-confirm-02 measured-supplement-02; do
 if python3 scripts/measured_study.py run --binary build-release/tokenfs --spec "study-configs/$batch.json" --output "/home/wjxt/aura-kv-cn7/evidence/$batch" --remote-root /srv/tokenfs/remote-cn7 --trace-dir /home/wjxt/tokenfs-public-traces --remove-generated-data > "/home/wjxt/aura-kv-cn7/evidence/$batch.log" 2>&1; then result=0; else result=$?; fi
 echo "$result" > "/home/wjxt/aura-kv-cn7/evidence/$batch.exit"
 test "$result" = 0
 python3 scripts/measured_study.py report --output "/home/wjxt/aura-kv-cn7/evidence/$batch"
done
batch=measured-domain-supplement-01
if python3 scripts/measured_domain_study.py run --binary build-release/tokenfs --reference /home/wjxt/aura-kv-cn7/evidence/measured-correctness-03/manifest.json --spec "study-configs/$batch.json" --output "/home/wjxt/aura-kv-cn7/evidence/$batch" --remote-root /srv/tokenfs/remote-cn7 > "/home/wjxt/aura-kv-cn7/evidence/$batch.log" 2>&1; then result=0; else result=$?; fi
echo "$result" > "/home/wjxt/aura-kv-cn7/evidence/$batch.exit"
test "$result" = 0
python3 scripts/measured_domain_study.py report --output "/home/wjxt/aura-kv-cn7/evidence/$batch"
