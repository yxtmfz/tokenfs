#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-reverse-20260929
python3 scripts/integrated_hpj_reverse_study.py run --spec study-configs/integrated-hpj-reverse-development.json --output /home/wjxt/tokenfs-integrated-hpj-reverse-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-reverse-20260929 --freeze study-configs/integrated-hpj-reverse-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-reverse-evidence/development.exit
exit "$rc"
