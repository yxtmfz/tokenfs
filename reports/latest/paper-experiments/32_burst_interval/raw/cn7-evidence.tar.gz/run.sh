#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-burst-interval-20260929
python3 scripts/burst_interval_study.py run --spec study-configs/burst-interval-development.json --output /home/wjxt/tokenfs-burst-interval-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/burst-interval-20260929 --freeze study-configs/burst-interval-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-burst-interval-evidence/development.exit
exit "$rc"
