#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-cohort-caller-independent-20260929
python3 scripts/integrated_hpj_cohort_caller_independent_study.py run --spec study-configs/integrated-hpj-cohort-caller-independent-development.json --output /home/wjxt/tokenfs-integrated-hpj-cohort-caller-independent-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-cohort-caller-independent-20260929 --freeze study-configs/integrated-hpj-cohort-caller-independent-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-cohort-caller-independent-evidence/development.exit
exit "$rc"
