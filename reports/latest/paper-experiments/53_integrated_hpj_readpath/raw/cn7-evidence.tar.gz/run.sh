#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-readpath-20260929
python3 scripts/integrated_hpj_readpath_study.py run --spec study-configs/integrated-hpj-readpath-development.json --output /home/wjxt/tokenfs-integrated-hpj-readpath-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-readpath-20260929 --freeze study-configs/integrated-hpj-readpath-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-readpath-evidence/development.exit
exit "$rc"
