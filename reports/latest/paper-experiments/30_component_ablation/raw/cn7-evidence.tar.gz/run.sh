#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-component-ablation-20260928
python3 scripts/component_ablation_study.py run --spec study-configs/component-ablation-development.json --output /home/wjxt/tokenfs-component-ablation-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/component-ablation-20260928 --freeze study-configs/component-ablation-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-component-ablation-evidence/development.exit
exit "$rc"
