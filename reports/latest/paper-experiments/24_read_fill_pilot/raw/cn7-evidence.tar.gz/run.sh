#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-read-fill-20260928
python3 scripts/read_fill_study.py run --spec study-configs/read-fill-development.json --output /home/wjxt/tokenfs-read-fill-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/read-fill-20260928 --freeze study-configs/read-fill-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-read-fill-evidence/development.exit
exit "$rc"
