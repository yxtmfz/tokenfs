#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-retained-20260929
python3 scripts/integrated_hpj_retained_study.py run --spec study-configs/integrated-hpj-retained-development.json --output /home/wjxt/tokenfs-integrated-hpj-retained-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-retained-20260929 --freeze study-configs/integrated-hpj-retained-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-retained-evidence/development.exit
exit "$rc"
