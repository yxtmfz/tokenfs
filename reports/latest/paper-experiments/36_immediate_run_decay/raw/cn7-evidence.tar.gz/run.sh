#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-run-decay-20260929
python3 scripts/run_decay_study.py run --spec study-configs/run-decay-development.json --output /home/wjxt/tokenfs-run-decay-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/run-decay-20260929 --freeze study-configs/run-decay-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-run-decay-evidence/development.exit
exit "$rc"
