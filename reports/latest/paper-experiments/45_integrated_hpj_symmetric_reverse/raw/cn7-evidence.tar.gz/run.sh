#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-symmetric-reverse-20260929
python3 scripts/integrated_hpj_symmetric_reverse_study.py run --spec study-configs/integrated-hpj-symmetric-reverse-development.json --output /home/wjxt/tokenfs-integrated-hpj-symmetric-reverse-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-symmetric-reverse-20260929 --freeze study-configs/integrated-hpj-symmetric-reverse-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-symmetric-reverse-evidence/development.exit
exit "$rc"
