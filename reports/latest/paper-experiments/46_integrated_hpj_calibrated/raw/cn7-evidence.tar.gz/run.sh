#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-calibrated-20260929
python3 scripts/integrated_hpj_calibrated_study.py run --spec study-configs/integrated-hpj-calibrated-development.json --output /home/wjxt/tokenfs-integrated-hpj-calibrated-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-calibrated-20260929 --freeze study-configs/integrated-hpj-calibrated-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-calibrated-evidence/development.exit
exit "$rc"
