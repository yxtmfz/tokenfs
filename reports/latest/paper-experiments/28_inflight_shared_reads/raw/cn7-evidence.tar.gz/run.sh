#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-inflight-shared-20260928
python3 scripts/inflight_shared_study.py run --spec study-configs/inflight-shared-development.json --output /home/wjxt/tokenfs-inflight-shared-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/inflight-shared-20260928 --freeze study-configs/inflight-shared-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-inflight-shared-evidence/development.exit
exit "$rc"
