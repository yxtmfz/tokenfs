#!/bin/bash
set -u
. /home/wjxt/aura-kv-tools/env.sh
cd /home/wjxt/projects/tokenfs-integrated-hpj-cohort-fence-20260929
python3 scripts/integrated_hpj_cohort_fence_study.py run --spec study-configs/integrated-hpj-cohort-fence-development.json --output /home/wjxt/tokenfs-integrated-hpj-cohort-fence-evidence/development --binary build-release/tokenfs --remote-root /srv/tokenfs/remote-cn7/integrated-hpj-cohort-fence-20260929 --freeze study-configs/integrated-hpj-cohort-fence-freeze.json
rc=$?
printf '%s\n' "$rc" > /home/wjxt/tokenfs-integrated-hpj-cohort-fence-evidence/development.exit
exit "$rc"
